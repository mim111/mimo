//
// BTDefines.h
// BingTranslate
//
// Created by Árpád Goretity on 20/10/2011.
// Licensed under a CreativeCommons Attribution 3.0 Unported License
//

#define BTResultKeySourceLanguage @"BTResultKeySourceLanguage"
#define BTResultKeyTranslation @"BTResultKeyTranslation"
